require 'byebug'
class Array

  # Monkey patch the Array class and add a my_inject method. If my_inject receives
  # no argument, then use the first element of the array as the default accumulator.

  def my_inject(accumulator = nil, &prc)
    accumulator = 0 if self.is_empty?
    accumulator = self[0] if accumulator == nil

    self.each do |ele|
      accumulator += prc.call(ele)
    end

    accumulator
  end


end

# primes(num) returns an array of the first "num" primes.
# You may wish to use an is_prime? helper method.

def is_prime?(num)
  return false if num < 2

  (0...num).each do |n|
    return false if num % n == 0
  end

  true
end

def primes(num)
  primes_arr = []

  while primes_arr.length < num
    (2..num).each do |n|
      primes_arr << n if is_prime?(n)
    end
  end

  primes_arr
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

def factorials_rec(num)

end

class Array

  # Write an Array#dups method that will return a hash containing the indices of all
  # duplicate elements. The keys are the duplicate elements; the values are
  # arrays of their indices in ascending order, e.g.
  # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    all_dups = Hash.new { |h, k| h[k] = [] }
    arr = []
    self.each_with_idx do |ele, idx|
      if !arr.include?(ele)
        arr << ele
      else
        all_dups[ele] << idx
      end
    end

    all_dups
  end

end

class String

  # Write a String#symmetric_substrings method that returns an array of substrings
  # that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
  # Only include substrings of length > 1.

  def symmetric_substrings
    subs = []

    (0...self.length).each do |idx|
      i = self.length - 1
      while i >= idx
        subs << if self[idx..i].is_palindrome?
        i -= 1
      end
    end

    subs

  end

  def is_palindrome?
    str_1 = ''
    str_2 = ''

    self.each_char do |char|
      str_1+=char
    end

    ((self.length - 1)).downto(0) do |idx|
      str_2 += self[idx]
    end

    str_1 == str_2  
  end

end

class Array

  # Write an Array#merge_sort method; it should not modify the original array.

  def merge_sort(&prc)
    mid = self.length / 2
    left_half = self[0...mid]
    right_half = self[mid..-1]

    left_sorted = left_half.merge_sort(&prc)
    right_sorted = right_half.merge_sort(&prc)

    Array.merge(left_sorted, right_sorted)
  end

  private
  def self.merge(left, right, &prc)
    merged = []

    until left.is_empty? || right.is_empty?
      if left[0] <= right[0]
        merged << left.shift
      else
        merged << right.shift
      end
    end

    merged + left + right
  end

end
